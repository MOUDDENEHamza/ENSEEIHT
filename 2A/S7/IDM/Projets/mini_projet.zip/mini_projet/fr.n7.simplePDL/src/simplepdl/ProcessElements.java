/**
 */
package simplepdl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Process Elements</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see simplepdl.SimplepdlPackage#getProcessElements()
 * @model abstract="true"
 * @generated
 */
public interface ProcessElements extends EObject {
} // ProcessElements

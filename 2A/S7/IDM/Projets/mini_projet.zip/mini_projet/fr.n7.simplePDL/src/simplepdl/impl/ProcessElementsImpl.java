/**
 */
package simplepdl.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import simplepdl.ProcessElements;
import simplepdl.SimplepdlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Process Elements</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ProcessElementsImpl extends MinimalEObjectImpl.Container implements ProcessElements {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ProcessElementsImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return SimplepdlPackage.Literals.PROCESS_ELEMENTS;
	}

} //ProcessElementsImpl

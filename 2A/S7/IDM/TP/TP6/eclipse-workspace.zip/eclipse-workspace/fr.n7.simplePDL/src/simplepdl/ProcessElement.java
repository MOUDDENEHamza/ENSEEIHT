/**
 */
package simplepdl;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Process Element</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see simplepdl.SimplepdlPackage#getProcessElement()
 * @model
 * @generated
 */
public interface ProcessElement extends EObject {
} // ProcessElement

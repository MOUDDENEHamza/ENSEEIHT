import java.io.*;

public interface SFiche extends Serializable {

	public String getNom ();
	public String getEmail ();
}




public class MessageTexte implements Message {
    private String pseudo;    // le pseudo ayant émis le message
    private String texte;    // le texte du message

    public MessageTexte(String pseudo, String texte) {
        this.pseudo = pseudo;
        this.texte = texte;
    }

    public String getPseudo() {
        return this.pseudo;
    }

    public String getTexte() {
        return this.texte;
    }

    public String toString() {
        return this.pseudo + " > " + this.texte;
    }
}
